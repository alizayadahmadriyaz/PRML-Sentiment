# SENTIMENT ANALYSIS

1. Clone the repo
2. Change the directory 
3. Run command "pip install -r requirements.txt"
4. Run command "python app.py"